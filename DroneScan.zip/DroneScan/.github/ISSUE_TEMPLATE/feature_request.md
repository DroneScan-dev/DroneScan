---
name: Feature request
about: Suggest an idea for DroneScan
title: "[FEATURE] "
labels: enhancement
---

**Is your feature request related to a problem?**
A clear description of the problem, e.g. "I'm unable to..."

**Describe the solution you'd like**
What you want to happen.

**Describe alternatives you've considered**
Any alternative solutions or features.

**Additional context**
Add any other context, mockups, or references here.
