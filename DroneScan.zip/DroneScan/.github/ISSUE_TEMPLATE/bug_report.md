---
name: Bug report
about: Report a problem with DroneScan
title: "[BUG] "
labels: bug
---

**Describe the bug**
A clear description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Run '...'
2. With config '...'
3. See error

**Expected behavior**
What you expected to happen.

**Environment**
- OS:
- Python version:
- Hardware (e.g. Jetson, x86 + GPU):
- DroneScan version/commit:

**Additional context**
Logs, screenshots, or sample footage (if shareable).
